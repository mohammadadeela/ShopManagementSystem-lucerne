import java.sql.Connection;

public class TestDB {
    public static void main(String[] args) {
        Connection con = new DataBaseConnection().getConnection().getConnection();
        if (con != null) System.out.println("Connection is working");
        else System.out.println("Connection failed");
    }
}
